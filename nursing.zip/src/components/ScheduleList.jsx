const ScheduleList = () => {
    return(
        <div>스케쥴리스트</div>
    );
};

export default ScheduleList;